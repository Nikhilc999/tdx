import { LightningElement, api, track } from 'lwc';

export default class SlackImageReplyForm extends LightningElement {
    @api contentVersionId;
    @api base64;
    @track replyText = '';

    get imageUrl() {
        return `/sfc/servlet.shepherd/version/download/${this.contentVersionId}`;
    }


}