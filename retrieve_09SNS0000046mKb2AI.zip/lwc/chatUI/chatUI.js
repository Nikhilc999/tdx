import { LightningElement, track, api } from 'lwc';
import askAgent from '@salesforce/apex/CallChatAgent.askAgent';
import endSession from '@salesforce/apex/CallChatAgent.endSession';
import appendMessageToCase from '@salesforce/apex/ChatEscalationController.appendMessageToCase';
import getCaseChatHistory from '@salesforce/apex/ChatEscalationController.getCaseChatHistory';
import getCaseStatus from '@salesforce/apex/ChatEscalationController.getCaseStatus';
import createEscalationCase from '@salesforce/apex/ChatEscalationController.createEscalationCase';
import updateChatCase from '@salesforce/apex/ChatEscalationController.updateChatCase';
import updateFallbackCase from '@salesforce/apex/ChatEscalationController.updateFallbackCase';
import updateFallbackCaseOwner from '@salesforce/apex/ChatEscalationController.updateFallbackCaseOwner';
import askAgentWithImage from '@salesforce/apex/CallChatAgent.askAgentWithImage';
import createEscalationCaseForImage from '@salesforce/apex/ChatEscalationController.createEscalationCaseForImage';
import tractorIcon from '@salesforce/resourceUrl/tractor1';

export default class ChatUI extends LightningElement {
    @track inputText = '';
    @track latestQuestion = '';
    @track messages = [];
    @api sessionId;
    @track showIntent = true;
    @track showForm = false;
    @track chatStarted = false;
    @track selectedIntent = '';
    contextHistory = [];
    @track sequenceId = 1;
    @track isLoading = false;
    @track isConnecting = false;
    @track isAgent = false;
    @track isAgentConnected = false;
    caseId;
    pollingInterval;
    @api recordId;
    // @track showContactForm = false;
    @track isChatWithSlack = false;
    tractorIcon = tractorIcon;
    lastSlackMessageCount = 0;
    lastSlackMessageCountForImage = 0;
    @track fileName = '';
    @track base64 = '';
    
    @track context = {
        location: '',
        landSize: '',
        soilType: '',
        experienceLevel: '',
        cropHistory: '',
        question: ''
    };
    @track farmerContact = {
        email: '',
        phone: ''
    };
    
    connectedCallback() {
        if (this.recordId != undefined && this.recordId.startsWith('500')) {
            this.isAgent = true;
            this.caseId = this.recordId;
            this.chatStarted = true;
            this.loadPreviousMessages();
            console.log('sss message ccb ',JSON.stringify(this.messages))
            this.pollingInterval = setInterval(() => {
              this.refreshMessages();
            }, 5000);
        }
    }
    selectIntent(event) {
        this.selectedIntent = event.target.dataset.id;
        this.context.intent = this.selectedIntent;
        this.showForm = true; 
        document.querySelectorAll('.intent-chip').forEach(chip => {
            chip.classList.remove('selected');
        });
    
        selectedChip.classList.add('selected');
    }

    get isNewFarmer() {
        return this.selectedIntent === 'new';
    }
    
    get isProfit() {
        return this.selectedIntent === 'profit';
    }
    
    get isRotation() {
        return this.selectedIntent === 'rotation';
    }

    startChat() {
        this.showForm = false;
        this.chatStarted = true;
        this.messages = [];
        this.sessionId = '';
        this.handleSend();
    }

    showChat() {
        this.context.intent = 'Freely';
        this.showForm = false;
        this.chatStarted = true;
    }

    handleInput(event) {
        this.context[event.target.name] = event.target.value;
    }

    handleInputText(event) {
        this.inputText = event.target.value;
    }

    async handleSend() {
        // this.showContactForm = this.showContactForm ? false : this.showContactForm;
        const userMessage = this.inputText;
        this.latestQuestion = this.inputText;
        this.inputText = '';
        if(this.recordId == undefined || this.recordId != this.caseId) {
            this.messages = [...this.messages, {
                id: Date.now(),
                sender: 'You',
                text: userMessage,
                cssClass: 'user-msg',
                isHtml: false,
                isSystem: false,
                isAgent: this.isAgent
            }];
            setTimeout(() => {
                this.scrollToBottom();
            }, 50);
        }
        console.log('sss handlesend farmer msg', JSON.stringify(this.messages));
        //await this.saveMessageToCase(userMessage, 'Farmer');
        if(this.caseId){
            await this.saveMessageToCase(userMessage, this.recordId != undefined && this.recordId == this.caseId ? 'Agent' : 'You');
            setTimeout(() => {
                this.scrollToBottom();
            }, 50);
            if(this.isChatWithSlack = true){
                this.updateFallbackCase();
            }
        } else {
            
            this.context.question = userMessage;
            this.isLoading = true;
            try {
                const response = await askAgent({
                    sessionId: this.sessionId, 
                    promptData: JSON.stringify(this.context),
                    sequenceId: this.sequenceId
                });

                this.sessionId = response.sessionId;
                const parsed = JSON.parse(response.response);
                const agentText = parsed?.messages[0]?.message || 'No response received.';
                const agentUnableToAnswer = agentText.toLowerCase().includes('unable to provide') ||
                                            agentText.toLowerCase().includes('cannot confidently recommend') ||
                                            agentText.toLowerCase().includes('sorry') ||
                                            agentText.toLowerCase().includes('trouble coming up with a response') ||
                                            agentText.toLowerCase().includes('I can help with questions');

                const jsonContent = this.parseMarkdownToJson(agentText);

                this.messages = [...this.messages, {
                    id: Date.now() + 1,
                    sender: 'Agent',
                    text: agentText,
                    parsed: jsonContent,
                    cssClass: 'agent-msg',
                    isHtml: true,
                    isSystem: false,
                    isAgent: this.isAgent,
                    showTalkToAgentButton: agentUnableToAnswer
                }];
                console.log('sss agent handle send messages ', JSON.stringify(this.messages));
                this.sequenceId++;
            } catch (error) {
                console.error('Agentforce call failed', error);
            } finally {
                console.log('sss final handle send messages ', JSON.stringify(this.messages));
                this.isLoading = false;
                setTimeout(() => {
                    this.scrollToBottom();
                }, 50);
            }
        }
    }

    scrollToBottom() {
        const container = this.template.querySelector('.chat-scroll-container');
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
    }

    formatMarkdown(text) {
        return text
            .replace(/### (.*)/g, '<h2>$1</h2>')
            .replace(/#### (.*)/g, '<h3>$1</h3>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n\n/g, '<br/><br/>')
            .replace(/\n- /g, '<li>')
            .replace(/- /g, '<li>')
            .replace(/\n[0-9]+\./g, match => '</li><li>' + match.replace(/\n/, '')) // numbered list
            .replace(/(?:^|\n)[0-9]+\./, '<ol><li>') + '</li></ol>';
    }

    handleCopy(event) {
        const id = event.target.dataset.id;
        const messageObj = this.messages.find(m => m.id === parseInt(id, 10));
        const text = JSON.stringify(messageObj.parsed, null, 2);
        navigator.clipboard.writeText(text);
    }
    
    handleThumbsUp() {
        console.log('Thumbs up clicked!');
    }
    
    handleThumbsDown() {
        console.log('Thumbs down clicked!');
    }

    handleImageUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
    
        const reader = new FileReader();
        reader.onload = () => {
            const base64 = reader.result;
            this.messages = [...this.messages, {
                id: Date.now(),
                sender: 'You',
                isImage: true,
                imageSrc: base64,
                cssClass: 'user-msg',
                isHtml: false,
                isSystem: false,
                isAgent: false
            }];
            setTimeout(() => this.scrollToBottom(), 50);
            this.sendImageToAgentforce(base64.split(',')[1], file.name);
        };
        reader.readAsDataURL(file);
    }
    
    async sendImageToAgentforce(base64, fileName) {
        this.isLoading = true;
        try {
            this.base64 = base64;
            this.fileName = fileName;
            const response = await askAgentWithImage({
                imageBase64: base64,
                prompt: 'Identify the crop issue, pest, soil condition, or deficiency from this image.'
            });
            const agentUnableToAnswer = response.toLowerCase().includes('I am unable') ||
            response.toLowerCase().includes('cannot confidently recommend') ||
            response.toLowerCase().includes('sorry') ||
            response.toLowerCase().includes('trouble coming up with a response');

            if(agentUnableToAnswer){
                this.handleTalkToAgentWithImage();
            } else {
                this.messages = [...this.messages, {
                    id: Date.now(),
                    sender: 'Agent',
                    text: response,
                    parsed: this.parseMarkdownToJson(response),
                    cssClass: 'agent-msg',
                    isHtml: true
                }];
            }
        } catch (error) {
            this.handleTalkToAgentWithImage();
            console.error('Image analysis failed', error);
        } finally {
            this.isLoading = false;
        }
    }

    handleTalkToAgentWithImage() {
        try {
            createEscalationCaseForImage({ base64Data: this.base64, fileName: this.fileName })
            .then(result => {
                this.caseId = result.caseId;
                //this.publicURL = result.publicUrl;
                this.isConnecting = false;
                // this.showContactForm = true;
                this.isChatWithSlack = true;
                this.isAgentConnected = true;
                this.messages = [...this.messages, {
                    id: Date.now(),
                    sender: 'System',
                    text: 'Agent has joined chat!',
                    cssClass: 'system-msg',
                    isHtml: false,
                    isSystem: true,
                    isAgent: this.isAgent
                }];
                this.saveMessageToCase('Agent has joined chat!', 'System');
                this.pollingInterval = setInterval(() => {
                    this.checkNewSlackMessagesForImage();
                }, 5000);
            })
            .catch(error => {
                console.error('Escalation error', error);
                this.isConnecting = false;
            });
        } catch (error) {
            console.error('Error creating escalation case', error);
        }
    }

    async checkNewSlackMessagesForImage() {
        if (!this.caseId) return;

        try {
            const historyLines = await getCaseChatHistory({ caseId: this.caseId });
    
            let startAdding = false;
            let slackNewMessages = [];
            let currentSender = 'Farmer'; // default
            let currentText = '';
            let skipCount = this.lastSlackMessageCountForImage;
    
            for (let line of historyLines) {
                line = line.trim();
    
                if (line.includes('[System]: Agent has joined chat!')) {
                    startAdding = true;
                    continue; // Skip system message itself
                }
    
                if (!startAdding) {
                    continue;
                }

                if (skipCount > 0) {
                    skipCount--;
                    continue;
                }
    
                if (line.startsWith('[Agent]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Agent';
                    currentText = line.replace('[Agent]:', '').trim();
                }
                else if (line.startsWith('[You]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Farmer';
                    currentText = line.replace('[You]:', '').trim();
                }
                else if (line.startsWith('[System]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'System';
                    currentText = line.replace('[System]:', '').trim();
                }
                else {
                    currentText += ' ' + line;
                }
            }
    
            if (currentText) {
                slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
            }

            this.lastSlackMessageCountForImage = this.lastSlackMessageCountForImage + slackNewMessages.length;
    
            if (slackNewMessages.length > 0) {
                if (this.messages.length === 0 ||
                    slackNewMessages[slackNewMessages.length - 1].text !== this.messages[this.messages.length - 1]?.text) {
                        
                    this.messages = [...this.messages, ...slackNewMessages];
                    
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, 50);
                }
            }
    
        } catch (error) {
            console.error('Error loading Slack expert replies:', error);
        }
    }
    
    parseMarkdownToJson(markdown) {
        const lines = markdown.split('\n');
        const blocks = [];
        let currentBlock = null;
    
        const createBlock = (type, content = '') => ({ type, content, children: [] });
    
        const pushCurrent = () => {
            if (currentBlock) blocks.push(currentBlock);
            currentBlock = null;
        };
    
        for (let line of lines) {
            line = line.trim();
            if (line === '') {
                pushCurrent();
                continue;
            }
    
            // Headings
            if (line.startsWith('### ')) {
                pushCurrent();
                currentBlock = createBlock('h3', line.slice(4));
            } else if (line.startsWith('## ')) {
                pushCurrent();
                currentBlock = createBlock('h2', line.slice(3));
            } else if (line.startsWith('# ')) {
                pushCurrent();
                currentBlock = createBlock('h1', line.slice(2));
            }
    
            // Ordered list
            else if (/^\d+\.\s/.test(line)) {
                if (!currentBlock || currentBlock.type !== 'ol') {
                    pushCurrent();
                    currentBlock = createBlock('ol');
                }
                currentBlock.children.push(line.replace(/^\d+\.\s/, ''));
            }
    
            // Unordered list
            else if (line.startsWith('- ') || line.startsWith('* ')) {
                if (!currentBlock || currentBlock.type !== 'ul') {
                    pushCurrent();
                    currentBlock = createBlock('ul');
                }
                currentBlock.children.push(line.slice(2));
            }
    
            // Paragraphs or inline code
            else {
                if (!currentBlock || currentBlock.type !== 'p') {
                    pushCurrent();
                    currentBlock = createBlock('p', line);
                } else {
                    currentBlock.content += ' ' + line;
                }
            }
        }
    
        pushCurrent();
        return blocks;
    }

    disconnectedCallback() {
        endSession({
            sessionId: this.sessionId
        })
        .then(() => {
            this.messages = [];
        }).catch(error => {
            console.log('sss error: ',error);
            this.messages = [];
        });
    }

    handleTalkToAgent() {
        this.isConnecting = true;
        console.log('sss handle talk to agent ', JSON.stringify(this.messages));
        const historyTexts = this.messages.map(m => `[${m.sender}]: ${m.text}`);
        console.log('sss historyTexts ', historyTexts);
        console.log('sss inputText ', this.inputText);
        try {
            createEscalationCase({ userQuestion: this.latestQuestion, history: historyTexts })
            .then(result => {
                this.caseId = result;
                this.connectionTimeout = setTimeout(() => {
                    if (this.isConnecting) {
                        clearInterval(this.pollingInterval);
                        updateFallbackCaseOwner({caseId: this.caseId});
                        this.isConnecting = false;
                        // this.showContactForm = true;
                        this.isChatWithSlack = true;
                        this.isAgentConnected = true;
                        this.messages = [...this.messages, {
                            id: Date.now(),
                            sender: 'System',
                            text: 'Sorry, no agent is available. Our experts will get back to you!',
                            cssClass: 'system-msg',
                            isHtml: false,
                            isSystem: true,
                            isAgent: this.isAgent
                        }];
                        this.saveMessageToCase('Sorry, no agent is available. Our experts will get back to you!', 'System');
                        this.updateFallbackCase();
                    }
                }, 30000);
                this.pollingInterval = setInterval(() => {
                    this.checkCaseStatus();
                }, 5000);
            })
            .catch(error => {
                console.error('Escalation error', error);
                this.isConnecting = false;
            });
        } catch (error) {
            console.error('Error creating escalation case', error);
        }
    }

    // handleEmailChange(event) {
    //     this.farmerContact.email = event.target.value;
    // }
    
    // handlePhoneChange(event) {
    //     this.farmerContact.phone = event.target.value;
    // }
    
    // handleContactFormSubmit() {
    //     if (!this.farmerContact.email && !this.farmerContact.phone) {
    //         alert('Please enter at least Email or Phone Number.');
    //         return;
    //     }
    //     this.updateFallbackCase();
    // }

    updateFallbackCase() {
        updateFallbackCase({ caseId: this.caseId, farmerQuestion: this.latestQuestion })
        .then(result => {
            this.pollingInterval = setInterval(() => {
                this.checkNewSlackMessages();
            }, 5000);
        })
    }

    async saveMessageToCase(text, sender) {
        if (!this.caseId) return;
        try {
            await appendMessageToCase({ caseId: this.caseId, newMessage: text, sender: sender });
        } catch (error) {
            alert('Sorry, an error occurred while connecting with the agent. Please try again later.')
            console.error('sss Error saving to case:', error);
        }
    }

    async checkNewSlackMessages() {
        if (!this.caseId) return;

        try {
            const historyLines = await getCaseChatHistory({ caseId: this.caseId });
    
            let startAdding = false;
            let slackNewMessages = [];
            let currentSender = 'Farmer'; // default
            let currentText = '';
            let skipCount = this.lastSlackMessageCount;
    
            for (let line of historyLines) {
                line = line.trim();
    
                if (line.includes('[System]: Sorry, no agent is available. Our experts will get back to you!')) {
                    startAdding = true;
                    continue; // Skip system message itself
                }
    
                if (!startAdding) {
                    continue;
                }

                if (skipCount > 0) {
                    skipCount--;
                    continue;
                }
    
                if (line.startsWith('[Agent]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Agent';
                    currentText = line.replace('[Agent]:', '').trim();
                }
                else if (line.startsWith('[You]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Farmer';
                    currentText = line.replace('[You]:', '').trim();
                }
                else if (line.startsWith('[System]:')) {
                    if (currentText) {
                        slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'System';
                    currentText = line.replace('[System]:', '').trim();
                }
                else {
                    currentText += ' ' + line;
                }
            }
    
            if (currentText) {
                slackNewMessages.push(this.buildMessage(currentSender, currentText, true));
            }

            this.lastSlackMessageCount = this.lastSlackMessageCount + slackNewMessages.length;
    
            if (slackNewMessages.length > 0) {
                if (this.messages.length === 0 ||
                    slackNewMessages[slackNewMessages.length - 1].text !== this.messages[this.messages.length - 1]?.text) {
                        
                    this.messages = [...this.messages, ...slackNewMessages];
                    
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, 50);
                }
            }
    
        } catch (error) {
            console.error('Error loading Slack expert replies:', error);
        }
    }

    async checkCaseStatus() {
        if (!this.caseId) return;

        const status = await getCaseStatus({ caseId: this.caseId });
        if ((status === 'In Progress' || status === 'Working' || status === 'Assigned') && this.isAgentConnected == false) {
            this.isAgentConnected = true;
            clearInterval(this.connectionTimeout);
            this.isConnecting = false;
            //this.isAgent = true;
            if(this.messages.length === 0 && this.recordId != undefined && this.recordId == this.caseId){
                this.loadPreviousMessages();
            }
            this.messages = [...this.messages, {
                id: Date.now(),
                sender: 'System',
                isHtml: false,
                isSystem: true,
                text: 'Agent has joined the chat!',
                cssClass: 'system-msg',
                isAgent: this.isAgent
            }];
            this.scrollToBottom();
            await this.saveMessageToCase('Agent has joined the chat!', 'System');
        } else if ((status === 'In Progress' || status === 'Working' || status === 'Assigned') && this.isAgentConnected == true) {
            this.loadNewAgentMessagesOnly();
        }else if(status == 'Closed'){
            this.caseId = null;
            this.isAgentConnected = false;
            clearInterval(this.pollingInterval);
            this.messages = [...this.messages, {
                id: Date.now(),
                sender: 'System',
                isHtml: false,
                isSystem: true,
                text: 'Agent has left the chat!',
                cssClass: 'system-msg',
                isAgent: this.isAgent
            }];
            console.log('sss case closed ',JSON.stringify(this.messages));
            console.log('sss isagent connected ', this.isAgentConnected);
        }
    }

    async handleEndChat(){
        this.caseId = null;
        this.isAgent = false;
        clearInterval(this.pollingInterval);
        // this.messages = [...this.messages, {
        //     id: Date.now(),
        //     sender: 'System',
        //     isHtml: false,
        //     isSystem: true,
        //     text: 'Agent has left the chat!',
        //     cssClass: 'system-msg',
        //     isAgent: this.isAgent
        // }];
        
    }

    async handleEndChatForAgent(){
        try{
            this.saveMessageToCase('Agent has left the chat!', 'System');
            console.log('sss 1');
            updateChatCase({ caseId: this.recordId, caseStatus: 'Closed' });
            console.log('sss 2');
            this.handleEndChat();
            console.log('sss 3');
        }catch(error){
            alert('Sorry, an error occurred while closing the case. Please try again later.')
            console.error('sss Error closing case:', error);
        }
    }

    async loadNewAgentMessagesOnly() {
        if (!this.caseId) return;
    
        try {
            const historyLines = await getCaseChatHistory({ caseId: this.caseId });
    
            let startAdding = false;
            let agentNewMessages = [];
            let currentSender = 'Farmer'; // default
            let currentText = '';
    
            for (let line of historyLines) {
                line = line.trim();
    
                if (line.includes('[System]: Agent has joined the chat!')) {
                    startAdding = true;
                    continue;
                }
    
                if (!startAdding) {
                    continue;
                }
    
                if (line.startsWith('[Agent]:')) {
                    if (currentText) {
                        agentNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Agent';
                    currentText = line.replace('[Agent]:', '').trim();
                }
                else if (line.startsWith('[You]:')) {
                    if (currentText) {
                        agentNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'Farmer';
                    currentText = line.replace('[You]:', '').trim();
                }
                else if (line.startsWith('[System]:')) {
                    if (currentText) {
                        agentNewMessages.push(this.buildMessage(currentSender, currentText, true));
                    }
                    currentSender = 'System';
                    currentText = line.replace('[System]:', '').trim();
                }
                else {
                    currentText += ' ' + line;
                }
            }
    
            if (currentText) {
                agentNewMessages.push(this.buildMessage(currentSender, currentText, true));
            }
    
            if (agentNewMessages.length > 0) {
                if (this.messages.length === 0 ||
                    agentNewMessages[agentNewMessages.length - 1].text !== this.messages[this.messages.length - 1]?.text) {
                    
                    this.messages = [...this.messages, ...agentNewMessages];
                    
                    setTimeout(() => {
                        this.scrollToBottom();
                    }, 50);
                }
            }
    
        } catch (error) {
            console.error('Error loading agent new messages:', error);
        }
    }

    buildMessage(sender, text, isFarmerChatwithAgent = false) {
        return {
            id: Date.now() + Math.floor(Math.random() * 1000),
            sender: sender,
            text: text.trim(),
            cssClass: this.getCssClass(sender),
            isHtml: sender === 'Agent',
            isSystem: sender === 'System',
            isAgent: this.isAgent,
            isFarmerChatwithAgent: isFarmerChatwithAgent
        };
    }

    async loadPreviousMessages() {
        if (!this.caseId) return;
    
        const historyLines = await getCaseChatHistory({ caseId: this.caseId });
    
        let messagesTemp = [];
        let currentSender = 'Farmer'; // default
        let currentText = '';
    
        for (let line of historyLines) {
            line = line.trim();
    
            if (line.startsWith('[Agent]:')) {
                if (currentText) {
                    messagesTemp.push({
                        id: Date.now() + messagesTemp.length,
                        sender: currentSender,
                        text: currentText.trim(),
                        cssClass: this.getCssClass(currentSender),
                        isHtml: currentSender === 'Agent',
                        isSystem: currentSender === 'System',
                        isAgent: this.isAgent
                    });
                }
                currentSender = 'Agent';
                currentText = line.replace('[Agent]:', '').trim();
            }
            else if (line.startsWith('[You]:')) {
                if (currentText) {
                    messagesTemp.push({
                        id: Date.now() + messagesTemp.length,
                        sender: currentSender,
                        text: currentText.trim(),
                        cssClass: this.getCssClass(currentSender),
                        isHtml: currentSender === 'Agent',
                        isSystem: currentSender === 'System',
                        isAgent: this.isAgent
                    });
                }
                currentSender = 'Farmer';
                currentText = line.replace('[You]:', '').trim();
            }
            else if (line.startsWith('[System]:')) {
                if (currentText) {
                    messagesTemp.push({
                        id: Date.now() + messagesTemp.length,
                        sender: currentSender,
                        text: currentText.trim(),
                        cssClass: this.getCssClass(currentSender),
                        isHtml: currentSender === 'Agent',
                        isSystem: currentSender === 'System',
                        isAgent: this.isAgent
                    });
                }
                currentSender = 'System';
                currentText = line.replace('[System]:', '').trim();
            }
            else {
                currentText += ' ' + line;
            }
        }
    
        // Push last message if pending
        if (currentText) {
            messagesTemp.push({
                id: Date.now() + messagesTemp.length,
                sender: currentSender,
                text: currentText,
                cssClass: this.getCssClass(currentSender),
                isHtml: currentSender === 'Agent',
                isSystem: currentSender === 'System',
                isAgent: this.isAgent
            });
        }
    
        this.messages = messagesTemp;
    }
    
    getCssClass(sender) {
        if (sender === 'Agent') return 'agent-msg';
        if (sender === 'System') return 'system-msg';
        return 'user-msg';
    }

    async refreshMessages() {
        if (!this.caseId) return;
    
        try {
            const historyLines = await getCaseChatHistory({ caseId: this.caseId });
    
            let newMessages = [];
            let currentSender = 'Farmer'; // default
            let currentText = '';
    
            for (let line of historyLines) {
                line = line.trim();
    
                if (line.startsWith('[Agent]:')) {
                    if (currentText) {
                        newMessages.push({
                            id: Date.now() + newMessages.length,
                            sender: currentSender,
                            text: currentText.trim(),
                            cssClass: this.getCssClass(currentSender),
                            isHtml: currentSender === 'Agent',
                            isSystem: currentSender === 'System',
                            isAgent: this.isAgent
                        });
                    }
                    currentSender = 'Agent';
                    currentText = line.replace('[Agent]:', '').trim();
                }
                else if (line.startsWith('[You]:')) {
                    if (currentText) {
                        newMessages.push({
                            id: Date.now() + newMessages.length,
                            sender: currentSender,
                            text: currentText.trim(),
                            cssClass: this.getCssClass(currentSender),
                            isHtml: currentSender === 'Agent',
                            isSystem: currentSender === 'System',
                            isAgent: this.isAgent
                        });
                    }
                    currentSender = 'Farmer';
                    currentText = line.replace('[You]:', '').trim();
                }
                else if (line.startsWith('[System]:')) {
                    if (currentText) {
                        newMessages.push({
                            id: Date.now() + newMessages.length,
                            sender: currentSender,
                            text: currentText.trim(),
                            cssClass: this.getCssClass(currentSender),
                            isHtml: currentSender === 'Agent',
                            isSystem: currentSender === 'System',
                            isAgent: this.isAgent
                        });
                    }
                    currentSender = 'System';
                    currentText = line.replace('[System]:', '').trim();
                }
                else {
                    currentText += ' ' + line;
                }
            }
    
            // Push last message if pending
            if (currentText) {
                newMessages.push({
                    id: Date.now() + newMessages.length,
                    sender: currentSender,
                    text: currentText.trim(),
                    cssClass: this.getCssClass(currentSender),
                    isHtml: currentSender === 'Agent',
                    isSystem: currentSender === 'System',
                    isAgent: this.isAgent
                });
            }
    
            // Smart update + scroll if new message received
            if (newMessages.length > this.messages.length) {
                this.messages = newMessages;
                setTimeout(() => {
                    this.scrollToBottom();
                }, 50);
            }
            else if (newMessages.length > 0 && 
                     (this.messages.length === 0 || 
                      newMessages[newMessages.length - 1].text !== this.messages[this.messages.length - 1].text)) {
                this.messages = newMessages;
                setTimeout(() => {
                    this.scrollToBottom();
                }, 50);
            }
            else {
                // No scroll needed
                this.messages = newMessages;
            }
    
        } catch (error) {
            console.error('Error refreshing messages:', error);
        }
    }
}