import { LightningElement, api, track } from 'lwc';

export default class GenericCard extends LightningElement {
    @api markdownJson = [];

    @track structuredBlocks = [];
    @track isStructuredBlock = true;
    @track displayText = '';
    @track cropRecommendations = [];
    @track isCropRecommendation = false;

    connectedCallback() {
        try{
            if (Array.isArray(this.markdownJson) && this.isCropRecommendationFormat(this.markdownJson)) {
                this.cropRecommendations = this.markdownJson;
                this.isCropRecommendation = true;
                this.isStructuredBlock = false;
            } else {
                this.structuredBlocks = this.buildDisplayModel(this.markdownJson);
                this.isStructuredBlock = true;
            }
        } catch(error) {
            this.isStructuredBlock = false;
            this.displayText = this.markdownJson;
        }
    }

    isCropRecommendationFormat(data) {
        return data.length > 0 && 
               data[0].cropName && 
               (data[0].summary || data[0].soilAdvice || data[0].pestManagement);
    }

    buildDisplayModel(data) {
        let output = [];
        let listStreak = 0;

        data.forEach((block, index) => {
        const id = 'block_' + index;

        if (['p', 'h1', 'h2', 'h3'].includes(block.type)) {
            listStreak = 0;
            output.push({
                id,
                isText: true,
                className: this.getTextClass(block.type),
                content: block.content
            });
        }

        if (block.type === 'ul' || block.type === 'ol') {
            listStreak++;
            let colorClass = listStreak % 2 === 1 ? 'list-card-alt' : 'list-card';

            // If only one in streak (not alternating), use normal class
            const isLast = index === data.length - 1 || !['ul', 'ol'].includes(data[index + 1]?.type);
            if (listStreak === 1 && isLast) {
                colorClass = 'list-card';
            }

            output.push({
                id,
                isList: true,
                items: block.children,
                listClass: colorClass
            });
        }
        });

        return output;
    }

    getTextClass(type) {
        switch (type) {
        case 'h1':
            return 'heading-1';
        case 'h2':
            return 'heading-2';
        case 'h3':
            return 'heading-3';
        default:
            return 'paragraph';
        }
    }
}